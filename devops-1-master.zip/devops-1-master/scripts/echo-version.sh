# Get Docker Version
docker -v